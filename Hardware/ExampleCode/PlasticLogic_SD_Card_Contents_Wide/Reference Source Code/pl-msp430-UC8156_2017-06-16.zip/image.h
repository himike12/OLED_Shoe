/*
 * image.h
 *
 *  Created on: 24 Aug 2016
 *      Author: andreas.meier
 */

#ifndef IMAGE_H_
#define IMAGE_H_

extern u8 visa_180x100[];
extern u8 image_74x312_1card[];
extern u8 image_8x8_scrambled_A[];

#endif /* IMAGE_H_ */
