/* --COPYRIGHT--,NULL
 **
 * --/COPYRIGHT--*/

unsigned char  detectCard (void);
