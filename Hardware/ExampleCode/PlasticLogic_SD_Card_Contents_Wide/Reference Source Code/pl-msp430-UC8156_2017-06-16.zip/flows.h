/*
 * flows.h
 *
 *  Created on: 24 Aug 2016
 *      Author: andreas.meier
 */

#ifndef FLOWS_H_
#define FLOWS_H_

	void eval_kit_flow(void);
	void debug_flow(void);
	void basic_flow(void);

#endif /* FLOWS_H_ */
