/*
 * display_functions.h
 *
 *  Created on: 24 Aug 2016
 *      Author: andreas.meier
 */

#ifndef DISPLAY_FUNCTIONS_H_
#define DISPLAY_FUNCTIONS_H_

void clear_display();
int show_image_from_SDcard(const char *image, int mode);


#endif /* DISPLAY_FUNCTIONS_H_ */
