#ifndef SLIDESHOW_H_
#define SLIDESHOW_H_

void slideshow_run(int mode, u16 delay_ms);

#endif
